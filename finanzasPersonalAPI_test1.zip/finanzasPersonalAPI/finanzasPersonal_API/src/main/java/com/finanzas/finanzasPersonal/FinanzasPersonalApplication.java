package com.finanzas.finanzasPersonal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FinanzasPersonalApplication {

	public static void main(String[] args) {
		SpringApplication.run(FinanzasPersonalApplication.class, args);
	}

}
