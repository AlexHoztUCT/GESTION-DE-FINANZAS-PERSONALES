package com.finanzas.finanzasPersonal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinanzasPersonalApplicationTests {

	@Test
	void contextLoads() {
	}

}
