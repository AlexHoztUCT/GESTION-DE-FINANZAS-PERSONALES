/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package patrones_estructurales;

/**
 *
 * @author Negr0.o
 */
import Database.DatabaseManager;
import Database.UserSession;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class ExpenseFacade {
    private static ExpenseFacade instance;
    
    private ExpenseFacade() {}
    
    public static ExpenseFacade getInstance() {
        if (instance == null) {
            instance = new ExpenseFacade();
        }
        return instance;
    }
    
    public void addExpense(int userId, int accountId, Date date, String category, 
                          String remark, double amount, JTable expenseTable) {
        try {
            DatabaseManager.connect();
            
            // 1. Verificar saldo en la cuenta
            if (!checkAccountBalance(accountId, amount)) {
                JOptionPane.showMessageDialog(null, "Fondos insuficientes, seleccione otra cuenta.");
                return;
            }
            
            // 2. Registrar el gasto
            registerExpense(userId, accountId, date, category, remark, amount);
            
            // 3. Actualizar el balance de la cuenta
            updateAccountBalance(accountId, amount);
            
            // 4. Actualizar la tabla de gastos
            updateExpenseTable(expenseTable, userId);
            
            JOptionPane.showMessageDialog(null, "Gasto registrado con éxito!");
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al registrar gasto: " + ex.getMessage());
        }
    }
    
    private boolean checkAccountBalance(int accountId, double amount) throws SQLException {
        String query = "SELECT balance FROM account WHERE account_id = ?";
        try (PreparedStatement pstmt = DatabaseManager.getConnection().prepareStatement(query)) {
            pstmt.setInt(1, accountId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getDouble("balance") >= amount;
            }
        }
        return false;
    }
    
    private void registerExpense(int userId, int accountId, Date date, 
                               String category, String remark, double amount) throws SQLException {
        String query = "INSERT INTO expense(user_id, account_id, expense_date, expense_category, remark, amount) VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement pstmt = DatabaseManager.getConnection().prepareStatement(query)) {
            pstmt.setInt(1, userId);
            pstmt.setInt(2, accountId);
            pstmt.setDate(3, new java.sql.Date(date.getTime()));
            pstmt.setString(4, category);
            pstmt.setString(5, remark);
            pstmt.setDouble(6, amount);
            pstmt.executeUpdate();
        }
    }
    
    private void updateAccountBalance(int accountId, double amount) throws SQLException {
        String query = "UPDATE account SET balance = balance - ?, liabilities = liabilities + ? WHERE account_id = ?";
        try (PreparedStatement pstmt = DatabaseManager.getConnection().prepareStatement(query)) {
            pstmt.setDouble(1, amount);
            pstmt.setDouble(2, amount);
            pstmt.setInt(3, accountId);
            pstmt.executeUpdate();
        }
    }
    
    public void updateExpenseTable(JTable expenseTable, int userId) {
        DefaultTableModel model = (DefaultTableModel) expenseTable.getModel();
        model.setRowCount(0);
        
        try {
            String query = "SELECT e.expense_date, e.expense_category, e.amount, e.remark, a.account_type " +
                         "FROM expense e " +
                         "INNER JOIN account a ON e.account_id = a.account_id " +
                         "WHERE e.user_id = ? ORDER BY e.expense_date DESC";
            
            try (PreparedStatement pstmt = DatabaseManager.getConnection().prepareStatement(query)) {
                pstmt.setInt(1, userId);
                ResultSet rs = pstmt.executeQuery();
                
                while (rs.next()) {
                    model.addRow(new Object[]{
                        rs.getString("account_type"),
                        rs.getString("expense_category"),
                        rs.getDouble("amount"),
                        rs.getDate("expense_date"),
                        rs.getString("remark")
                    });
                }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al actualizar tabla: " + ex.getMessage());
        }
    }
    
    public void populateExpenseCategories(javax.swing.JComboBox<String> comboBox) {
        try {
            comboBox.removeAllItems();
            comboBox.addItem("--SELECCIONAR--");
            
            DatabaseManager.connect();
            String query = "SELECT category_name FROM expense_category WHERE user_id = ?";
            
            try (PreparedStatement pstmt = DatabaseManager.getConnection().prepareStatement(query)) {
                pstmt.setInt(1, UserSession.userId);
                ResultSet rs = pstmt.executeQuery();
                
                while (rs.next()) {
                    comboBox.addItem(rs.getString("category_name"));
                }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al cargar categorías: " + ex.getMessage());
        }
    }
    
    public void addNewExpenseCategory(String category) {
        if (category.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Ingrese un nombre de categoría");
            return;
        }
        
        try {
            DatabaseManager.connect();
            
            // Verificar si ya existe
            String checkQuery = "SELECT COUNT(*) FROM expense_category WHERE user_id = ? AND category_name = ?";
            try (PreparedStatement checkStmt = DatabaseManager.getConnection().prepareStatement(checkQuery)) {
                checkStmt.setInt(1, UserSession.userId);
                checkStmt.setString(2, category);
                ResultSet rs = checkStmt.executeQuery();
                
                if (rs.next() && rs.getInt(1) > 0) {
                    JOptionPane.showMessageDialog(null, "La categoría ya existe");
                    return;
                }
            }
            
            // Insertar nueva categoría
            String insertQuery = "INSERT INTO expense_category (user_id, category_name) VALUES (?, ?)";
            try (PreparedStatement pstmt = DatabaseManager.getConnection().prepareStatement(insertQuery)) {
                pstmt.setInt(1, UserSession.userId);
                pstmt.setString(2, category);
                pstmt.executeUpdate();
                JOptionPane.showMessageDialog(null, "Categoría agregada con éxito");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al agregar categoría: " + ex.getMessage());
        }
    }
}