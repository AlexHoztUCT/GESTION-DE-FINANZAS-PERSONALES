/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package patrones_estructurales;

/**
 *
 * @author maxim
 */
import javax.swing.JPanel;
import java.util.Date;

public class LoggingDecorator implements UIComponent {
    private final UIComponent wrappedComponent;

    public LoggingDecorator(UIComponent component) {
        this.wrappedComponent = component;
    }

    @Override
    public JPanel getPanel() {
        logAccess();
        return wrappedComponent.getPanel();
    }

    private void logAccess() {
        System.out.println("[LOG] Componente accedido: " 
            + wrappedComponent.getClass().getSimpleName() 
            + " - " + new Date());
    }
}