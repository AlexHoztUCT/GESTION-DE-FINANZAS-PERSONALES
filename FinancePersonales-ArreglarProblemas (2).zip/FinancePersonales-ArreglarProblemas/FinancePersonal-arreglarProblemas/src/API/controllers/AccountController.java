/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package API.controllers;

import API.models_db.Account;
import API.services.AccountService;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.*;
import java.util.List;

@Path("/accounts")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class AccountController {
    
    private final AccountService accountService = new AccountService();

    @GET
    public Response getAllAccounts() {
        List<Account> accounts = accountService.getAllAccounts();
        return Response.ok(accounts).build();
    }

    @GET
    @Path("/{id}")
    public Response getAccountById(@PathParam("id") int id) {
        Account account = accountService.getAccountById(id);
        if (account != null) {
            return Response.ok(account).build();
        } else {
            return Response.status(Response.Status.NOT_FOUND).build();
        }
    }

    @POST
    public Response createAccount(Account account, @Context UriInfo uriInfo) {
        Account createdAccount = accountService.createAccount(account);
        UriBuilder builder = uriInfo.getAbsolutePathBuilder();
        builder.path(Integer.toString(createdAccount.getAccountId()));
        return Response.created(builder.build()).entity(createdAccount).build();
    }

    @PUT
    @Path("/{id}")
    public Response updateAccount(@PathParam("id") int id, Account account) {
        account.setAccountId(id);
        Account updatedAccount = accountService.updateAccount(account);
        return Response.ok(updatedAccount).build();
    }

    @DELETE
    @Path("/{id}")
    public Response deleteAccount(@PathParam("id") int id) {
        accountService.deleteAccount(id);
        return Response.noContent().build();
    }
}
