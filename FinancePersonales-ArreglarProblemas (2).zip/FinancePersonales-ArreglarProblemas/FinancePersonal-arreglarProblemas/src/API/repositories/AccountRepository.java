/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

// ACCESO A DATOS

package API.repositories;

import API.models_db.Account;
import java.util.ArrayList;
import java.util.List;

public class AccountRepository {
    // Esto es temporal - en una aplicación real usarías JDBC o JPA
    private static List<Account> accounts = new ArrayList<>();
    private static int nextId = 1;
    
    public List<Account> findAll() {
        return new ArrayList<>(accounts);
    }
    
    public Account findById(int id) {
        return accounts.stream()
                .filter(a -> a.getAccountId() == id)
                .findFirst()
                .orElse(null);
    }
    
    public Account save(Account account) {
        account.setAccountId(nextId++);
        accounts.add(account);
        return account;
    }
    
    public Account update(Account account) {
        Account existing = findById(account.getAccountId());
        if (existing != null) {
            existing.setUserId(account.getUserId());
            existing.setAccountType(account.getAccountType());
            existing.setBalance(account.getBalance());
            existing.setLiabilities(account.getLiabilities());
        }
        return existing;
    }
    
    public void delete(int id) {
        accounts.removeIf(a -> a.getAccountId() == id);
    }
}
