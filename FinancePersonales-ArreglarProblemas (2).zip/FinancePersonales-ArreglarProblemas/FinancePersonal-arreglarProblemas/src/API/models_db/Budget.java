/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package API.models_db;

/**
 *
 * @author alexi
 */

public class Budget {
    private int budget_id;
    private int user_id;
    private String expense_category;
    private double amount;

    public Budget() {}

    public Budget(int budgetId, int userId, String expenseCategory, double amount) {
        this.budget_id= budgetId;
        this.user_id = userId;
        this.expense_category = expenseCategory;
        this.amount = amount;
    }

    public int getBudgetId() { return budget_id; }
    public void setBudgetId(int budgetId) { this.budget_id = budgetId; }

    public int getUserId() { return user_id; }
    public void setUserId(int userId) { this.user_id = userId; }

    public String getExpenseCategory() { return expense_category; }
    public void setExpenseCategory(String expenseCategory) { this.expense_category = expenseCategory; }

    public double getAmount() { return amount; }
    public void setAmount(double amount) { this.amount = amount; }
}
