/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package API.models_db;
import java.sql.Timestamp;

/**
 *
 * @author alexi
 */

public class Transaction {
    private int transaction_id;
    private int account_id;
    private String type;
    private double amount;
    private String statement;
    private Timestamp time;

    public Transaction() {}

    public Transaction(int transactionId, int accountId, String type, double amount, String statement, Timestamp time) {
        this.transaction_id = transactionId;
        this.account_id = accountId;
        this.type = type;
        this.amount = amount;
        this.statement = statement;
        this.time = time;
    }

    public int getTransactionId() { return transaction_id; }
    public void setTransactionId(int transactionId) { this.transaction_id = transactionId; }

    public int getAccountId() { return account_id; }
    public void setAccountId(int accountId) { this.account_id = accountId; }

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }

    public double getAmount() { return amount; }
    public void setAmount(double amount) { this.amount = amount; }

    public String getStatement() { return statement; }
    public void setStatement(String statement) { this.statement = statement; }

    public Timestamp getTime() { return time; }
    public void setTime(Timestamp time) { this.time = time; }
}

