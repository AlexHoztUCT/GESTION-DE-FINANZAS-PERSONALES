/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package config;

import org.glassfish.jersey.servlet.ServletContainer;
import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.servlet.ServletContextHandler;
import org.eclipse.jetty.servlet.ServletHolder;
import org.glassfish.jersey.server.ResourceConfig;
import API.controllers.AccountController;

public class Main {
    public static void main(String[] args) {
        int port = 8080;

        // Configurar Jersey
        ResourceConfig config = new ResourceConfig();
        config.register(AccountController.class);  // Registra la clase directamente

        // Crear contenedor Jetty
        ServletContextHandler context = new ServletContextHandler(ServletContextHandler.SESSIONS);
        context.setContextPath("/api");  // El prefijo para tus endpoints será /api

        ServletHolder servletHolder = new ServletHolder(new ServletContainer(config));
        context.addServlet(servletHolder, "/*");

        Server server = new Server(port);
        server.setHandler(context);

        try {
            server.start();
            System.out.println("✅ Servidor iniciado en http://localhost:" + port + "/api/hello");
            server.join();
        } catch (Exception e) {
            System.err.println("❌ Error al iniciar el servidor:");
            e.printStackTrace();
        }
    }
}



