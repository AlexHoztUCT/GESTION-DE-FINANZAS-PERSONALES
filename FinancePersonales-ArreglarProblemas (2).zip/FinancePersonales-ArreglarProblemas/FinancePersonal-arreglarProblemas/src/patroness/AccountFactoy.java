package patroness;

/*
 *
 * @author User
 */

public interface AccountFactoy {
    Cuenta crearCuenta(String nombre, int userId);
}


