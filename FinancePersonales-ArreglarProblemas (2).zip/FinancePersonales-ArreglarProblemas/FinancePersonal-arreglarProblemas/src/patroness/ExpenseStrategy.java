/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package patroness;

/**
 *
 * @author DCalf
 */

import java.sql.SQLException;
import java.sql.Date;

public interface ExpenseStrategy {
    void processExpense(int userId, int accountId, Date expenseDate, String category, double amount) throws SQLException;
}