/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package prototype;

/**
 *
 * @author User
 */
public abstract class Cuenta {
    protected String nombre;
    protected int userId;

    public Cuenta(String nombre, int userId) {
        this.nombre = nombre;
        this.userId = userId;
    }

    public abstract void guardarEnBD(); // Este método lo llamarás desde la UI
}

