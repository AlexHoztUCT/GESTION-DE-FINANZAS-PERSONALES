/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prototype;

/**
 *
 * @author User
 */
public class CuentaBasicaFactory implements AccountFactoy {
    @Override
    public Cuenta crearCuenta(String nombre, int userId) {
        return new CuentaBasica(nombre, userId);
    }
}

