/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package models_db;
import java.util.Date;


/**
 *
 * @author alexi
 */
public class Expense {
    private int expense_id;
    private int user_id;
    private int account_id;
    private Date expense_date;
    private String expense_category;
    private String remark;
    private double amount;

    public Expense() {}

    public Expense(int expenseId, int userId, int accountId, Date expenseDate, String expenseCategory, String remark, double amount) {
        this.expense_id = expenseId;
        this.user_id = userId;
        this.account_id = accountId;
        this.expense_date = expenseDate;
        this.expense_category = expenseCategory;
        this.remark = remark;
        this.amount = amount;
    }

    public int getExpenseId() { return expense_id; }
    public void setExpenseId(int expenseId) { this.expense_id = expenseId; }

    public int getUserId() { return user_id; }
    public void setUserId(int userId) { this.user_id = userId; }

    public int getAccountId() { return account_id; }
    public void setAccountId(int accountId) { this.account_id = accountId; }

    public Date getExpenseDate() { return expense_date; }
    public void setExpenseDate(Date expenseDate) { this.expense_date = expenseDate; }

    public String getExpenseCategory() { return expense_category; }
    public void setExpenseCategory(String expenseCategory) { this.expense_category = expenseCategory; }

    public String getRemark() { return remark; }
    public void setRemark(String remark) { this.remark = remark; }

    public double getAmount() { return amount; }
    public void setAmount(double amount) { this.amount = amount; }
}
