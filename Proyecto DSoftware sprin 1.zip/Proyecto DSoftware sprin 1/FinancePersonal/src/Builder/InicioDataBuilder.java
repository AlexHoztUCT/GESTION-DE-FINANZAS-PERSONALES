/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Builder;

/**
 *
 * @author User
 */
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 *
 * @author User
 */
import javax.swing.table.DefaultTableModel;
import java.sql.SQLException;
import Database.DatabaseManager;


public class InicioDataBuilder {
    private InicioData data;

    public InicioDataBuilder() {
        data = new InicioData();
    }

    public InicioDataBuilder buildBalances(int userId) throws SQLException {
        String balanceQuery = "SELECT COALESCE(SUM(balance), 0) AS total_balance FROM account WHERE user_id = ?";
        String liabilitiesQuery = "SELECT COALESCE(SUM(liabilities), 0) AS total_liabilities FROM account WHERE user_id = ?";
        String incomeQuery = "SELECT COALESCE(SUM(amount), 0) AS total_income FROM income WHERE user_id = ? AND MONTH(income_date) = MONTH(NOW()) AND YEAR(income_date) = YEAR(NOW())";
        String expenseQuery = "SELECT COALESCE(SUM(amount), 0) AS total_expense FROM expense WHERE user_id = ? AND MONTH(expense_date) = MONTH(NOW()) AND YEAR(expense_date) = YEAR(NOW())";

        var conn = DatabaseManager.getConnection();

        var ps = conn.prepareStatement(balanceQuery);
        ps.setInt(1, userId);
        var rs = ps.executeQuery();
        if (rs.next()) data.totalBalance = (int) rs.getDouble("total_balance");
        rs.close();
        ps.close();

        ps = conn.prepareStatement(liabilitiesQuery);
        ps.setInt(1, userId);
        rs = ps.executeQuery();
        if (rs.next()) data.totalLiabilities = (int) rs.getDouble("total_liabilities");
        rs.close();
        ps.close();

        ps = conn.prepareStatement(incomeQuery);
        ps.setInt(1, userId);
        rs = ps.executeQuery();
        if (rs.next()) data.totalIncome = (int) rs.getDouble("total_income");
        rs.close();
        ps.close();

        ps = conn.prepareStatement(expenseQuery);
        ps.setInt(1, userId);
        rs = ps.executeQuery();
        if (rs.next()) data.totalExpense = (int) rs.getDouble("total_expense");
        rs.close();
        ps.close();

        return this;
    }

    public InicioDataBuilder buildTransactions(int userId) throws SQLException {
        DefaultTableModel model = new DefaultTableModel(new Object[] {
            "Transación Id", "Cuenta Id", "Tipo de Transacción", "Monto", "Nota", "Fecha"
        }, 0);

        String query = "SELECT t.transaction_id, t.type, t.amount, t.statement, t.time, a.account_type " +
                "FROM transaction t " +
                "INNER JOIN account a ON t.account_id = a.account_id " +
                "WHERE a.user_id = ? ORDER BY t.time DESC";

        var conn = DatabaseManager.getConnection();
        var ps = conn.prepareStatement(query);
        ps.setInt(1, userId);
        var rs = ps.executeQuery();

        while (rs.next()) {
            model.addRow(new Object[] {
                rs.getInt("transaction_id"),
                rs.getString("account_type"),
                rs.getString("type"),
                rs.getDouble("amount"),
                rs.getString("statement"),
                rs.getString("time")
            });
        }
        rs.close();
        ps.close();

        data.transactionsModel = model;
        return this;
    }

    public InicioDataBuilder buildProgress(int userId) throws SQLException {
        var conn = DatabaseManager.getConnection();

        // Obtener ingresos totales mes actual
        String incomeQuery = "SELECT COALESCE(SUM(amount), 0) AS total_income FROM income WHERE user_id = ? AND MONTH(income_date) = MONTH(CURRENT_DATE()) AND YEAR(income_date) = YEAR(CURRENT_DATE())";
        var ps = conn.prepareStatement(incomeQuery);
        ps.setInt(1, userId);
        var rs = ps.executeQuery();
        double totalIncome = 0;
        if (rs.next()) totalIncome = rs.getDouble("total_income");
        rs.close();
        ps.close();

        // Obtener gastos totales mes actual
        String expenseQuery = "SELECT COALESCE(SUM(amount), 0) AS total_expense FROM expense WHERE user_id = ? AND MONTH(expense_date) = MONTH(CURRENT_DATE()) AND YEAR(expense_date) = YEAR(CURRENT_DATE())";
        ps = conn.prepareStatement(expenseQuery);
        ps.setInt(1, userId);
        rs = ps.executeQuery();
        double totalExpense = 0;
        if (rs.next()) totalExpense = rs.getDouble("total_expense");
        rs.close();
        ps.close();

        int savedMoney = (int) (totalIncome - totalExpense);

        // Obtener monto objetivo
        String targetQuery = "SELECT amount FROM target_amount WHERE user_id = ?";
        ps = conn.prepareStatement(targetQuery);
        ps.setInt(1, userId);
        rs = ps.executeQuery();
        double targetAmount = 0;
        if (rs.next()) targetAmount = rs.getDouble("amount");
        rs.close();
        ps.close();

        double percentage = 0;
        if (targetAmount != 0) {
            percentage = (savedMoney / targetAmount) * 100;
        }

        data.progressValue = (int) Math.round(percentage);
        data.progressText = savedMoney + "/" + targetAmount;

        return this;
    }

    public InicioData build() {
        return data;
    }
}
