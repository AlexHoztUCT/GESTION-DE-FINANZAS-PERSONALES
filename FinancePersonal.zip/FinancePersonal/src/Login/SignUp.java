/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Login;

import javax.swing.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;
import Database.DatabaseManager;
import com.formdev.flatlaf.themes.FlatMacLightLaf;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

class PasswordException extends Exception {
    public PasswordException(String message) {
        super(message);
    }
}

public class SignUp extends javax.swing.JFrame {
    public SignUp() {
        initComponents();
    }

    // retriccion de contraseña
    private void passwordRestrictions(String password) throws PasswordException {
        // Se define las restricciones de contraseña
        int minLength = 8;
        String specialCharacters = "!@#$%^&*()_+";

        // comprobar la longitud minima
        if (password.length() < minLength) {
            throw new PasswordException("la contraaseña debe tener al menos " + minLength + " caracteres de largo.");
        }

        // Comprobar si hay caracteres especiales
        Pattern pattern = Pattern.compile("[^a-zA-Z0-9]");
        Matcher matcher = pattern.matcher(password);
        if (!matcher.find()) {
            throw new PasswordException(" La contraseña debe tener al menos un carácter especial.");
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        name = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        username = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        password = new javax.swing.JPasswordField();
        jButton1 = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Sign Up");
        setMinimumSize(new java.awt.Dimension(900, 600));
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setMaximumSize(new java.awt.Dimension(900, 600));
        jPanel1.setMinimumSize(new java.awt.Dimension(900, 600));
        jPanel1.setPreferredSize(new java.awt.Dimension(900, 600));
        jPanel1.setLayout(null);

        jPanel2.setBackground(new java.awt.Color(204, 0, 0));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/FINTRACK LOGO.png"))); // NOI18N

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 360, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(200, 200, 200)
                .addComponent(jLabel1)
                .addContainerGap(201, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel2);
        jPanel2.setBounds(0, 0, 360, 600);

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));

        jLabel4.setFont(new java.awt.Font("Lucida Bright", 1, 36)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 102, 102));
        jLabel4.setText("REGÍSTRATE");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        jLabel3.setText("Nombre");

        name.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        name.setForeground(new java.awt.Color(102, 102, 102));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        jLabel5.setText("Nombre de Usuario");

        username.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        username.setForeground(new java.awt.Color(102, 102, 102));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        jLabel6.setText("Contraseña");

        password.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                passwordActionPerformed(evt);
            }
        });

        jButton1.setBackground(new java.awt.Color(0, 0, 0));
        jButton1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("REGÍSTRATE");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Lucida Bright", 0, 14)); // NOI18N
        jLabel7.setText("¿Ya tienes una cuenta?");

        jButton2.setBackground(new java.awt.Color(0, 0, 0));
        jButton2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.setText("INICIAR SESIÓN");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(name, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(username, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(password, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(53, 53, 53)
                        .addComponent(jButton2)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(77, 77, 77))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(143, Short.MAX_VALUE)
                .addComponent(jLabel4)
                .addGap(133, 133, 133))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(45, 45, 45)
                .addComponent(jLabel4)
                .addGap(18, 18, 18)
                .addComponent(jLabel3)
                .addGap(7, 7, 7)
                .addComponent(name, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(username, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(password, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jLabel7)
                .addContainerGap(133, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel3);
        jPanel3.setBounds(370, 50, 510, 520);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

 // Método que se llama cuando se activa el evento de acción del campo de contraseña
private void passwordActionPerformed(java.awt.event.ActionEvent evt) {
    // Este método está vacío, se puede usar para manejar el evento de presionar "Enter" en el campo de contraseña
}

// Método que se llama cuando se hace clic en el botón "Registrar"
private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {// GEN-FIRST:event_jButton1ActionPerformed

    try {
        // Conectar a la base de datos
        DatabaseManager.connect();

        // Obtener los valores introducidos en los campos de texto
        String name1 = name.getText();          // Obtener el nombre
        String username1 = username.getText();  // Obtener el nombre de usuario
        String password1 = password.getText();  // Obtener la contraseña

        // Comprobar si alguno de los campos está vacío
        if (name1.isEmpty() || username1.isEmpty() || password1.isEmpty()) {
            String errorMessage = "Por favor, rellene los siguientes campos";
            // Agregar campos vacíos al mensaje de error
            if (name1.isEmpty())
                errorMessage += "\n- Nombre";
            if (username1.isEmpty())
                errorMessage += "\n- Nombre de Usuario";
            if (password1.isEmpty())
                errorMessage += "\n- Contraseña";
            // Mostrar mensaje de error
            JOptionPane.showMessageDialog(null, errorMessage);
            return; // Salir del método si hay campos vacíos
        }

        // Verificar las restricciones de la contraseña (se refiere a un método no mostrado aquí)
        passwordRestrictions(password1);

        // Comprobar si el nombre de usuario ya existe en la base de datos
        String query = "SELECT * FROM user WHERE username = ?";
        PreparedStatement pstmt = DatabaseManager.getConnection().prepareStatement(query);
        pstmt.setString(1, username1); // Establecer el nombre de usuario en la consulta
        ResultSet rs = pstmt.executeQuery(); // Ejecutar la consulta

        // Si se encuentra un resultado, significa que el nombre de usuario ya existe
        if (rs.next()) {
            JOptionPane.showMessageDialog(null, "El nombre de usuario ya existe, por favor, elige otro.");
            return; // Salir del método si el nombre de usuario ya existe
        }

        // Si el nombre de usuario no existe y la contraseña cumple con las restricciones, proceder a la inserción
        query = "INSERT INTO user(name, username, password) VALUES (?, ?, ?)";
        pstmt = DatabaseManager.getConnection().prepareStatement(query);
        pstmt.setString(1, name1);           // Establecer el nombre
        pstmt.setString(2, username1);       // Establecer el nombre de usuario
        pstmt.setString(3, password1);       // Establecer la contraseña

        // Ejecutar la actualización y obtener el número de filas insertadas
        int rowsInserted = pstmt.executeUpdate();
        if (rowsInserted > 0) {
            // Inserción exitosa
            // Limpiar los campos de texto
            name.setText("");
            username.setText("");
            password.setText("");
            // Mostrar mensaje de éxito
            JOptionPane.showMessageDialog(null, "Cuenta creada con éxito!");
        }
    } catch (PasswordException ex) {
        // Manejar excepciones específicas de la contraseña
        JOptionPane.showMessageDialog(null, "Error de contraseña " + ex.getMessage());
    } catch (SQLException ex) {
        // Manejar excepciones SQL
        ex.printStackTrace(); // Imprimir la traza de la excepción
        JOptionPane.showMessageDialog(null, "Se produjo un error al crear la cuenta " + ex.getMessage());
    } catch (Exception ex) {
        // Manejar otras excepciones
        ex.printStackTrace(); // Imprimir la traza de la excepción
        JOptionPane.showMessageDialog(null, "Ha ocurrido un error inesperado " + ex.getMessage());
    }

}

// Método que se llama cuando se hace clic en el botón para volver a la pantalla de inicio de sesión
private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {
    // Crear un nuevo frame de inicio de sesión
    Login LoginFrame = new Login();
    LoginFrame.setVisible(true); // Hacer visible el frame
    LoginFrame.pack(); // Ajustar el tamaño del frame
    LoginFrame.setLocationRelativeTo(null); // Centrar el frame en la pantalla
    this.dispose(); // Cerrar la ventana actual (SignUp)
}

/**
 * @param args the command line arguments
 */
public static void main(String args[]) {
    FlatMacLightLaf.setup(); // Configurar el Look and Feel

    /* Crear y mostrar el formulario */
    java.awt.EventQueue.invokeLater(new Runnable() {
        public void run() {
            new SignUp().setVisible(true); // Crear y mostrar la ventana de registro
        }
    });
}

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JTextField name;
    private javax.swing.JPasswordField password;
    private javax.swing.JTextField username;
    // End of variables declaration//GEN-END:variables
    private Connection con;
    private ResultSet rs;
}
