/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package patroness;

/**
 *
 * @author DCalf
 */

import Database.*;
import javax.swing.*;
import com.toedter.calendar.JDateChooser;
import java.sql.*;
import java.util.Date;

public class AddExpenseStrategy{

    private final Date expenseDate;
    private final String accountName;
    private final String expenseCategory;
    private final String expenseAmountText;
    private final JComboBox<String> expenseAccountName;
    private final JComboBox<String> expenseCategoryComboBox;
    private final JTextField expenseAmount;
    private final JDateChooser expenseDateChooser;
    private final Runnable onSuccess;
    private final ExpenseStrategy strategy;

    public AddExpenseStrategy(
            JDateChooser expenseDateChooser,
            JComboBox<String> expenseAccountName,
            JComboBox<String> expenseCategoryComboBox,
            JTextField expenseAmount,
            Runnable onSuccess,
            ExpenseStrategy strategy
    ) {
        this.expenseDateChooser = expenseDateChooser;
        this.expenseAccountName = expenseAccountName;
        this.expenseCategoryComboBox = expenseCategoryComboBox;
        this.expenseAmount = expenseAmount;
        this.expenseDate = expenseDateChooser.getDate();
        this.accountName = (String) expenseAccountName.getSelectedItem();
        this.expenseCategory = (String) expenseCategoryComboBox.getSelectedItem();
        this.expenseAmountText = expenseAmount.getText();
        this.onSuccess = onSuccess;
        this.strategy = strategy;
    }

    public void execute() {
        if (expenseDate == null || accountName.equals("--SELECCIONAR--") ||
            expenseCategory.equals("--SELECCIONAR--") || expenseAmountText.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Por favor, complete todos los campos.");
            return;
        }

        try {
            double amount = Double.parseDouble(expenseAmountText);
            java.sql.Date sqlDate = new java.sql.Date(expenseDate.getTime());

            DatabaseManager.connect();
            String accountQuery = "SELECT account_id FROM account WHERE account_type = ? AND user_id = ?";
            PreparedStatement accountStmt = DatabaseManager.getConnection().prepareStatement(accountQuery);
            accountStmt.setString(1, accountName);
            accountStmt.setInt(2, UserSession.userId);
            ResultSet result = accountStmt.executeQuery();

            if (result.next()) {
                int accountId = result.getInt("account_id");
                strategy.processExpense(UserSession.userId, accountId, sqlDate, expenseCategory, amount);
                JOptionPane.showMessageDialog(null, "Gasto procesado con éxito.");
                expenseDateChooser.setDate(null);
                expenseAmount.setText("");
                expenseCategoryComboBox.setSelectedIndex(0);
                expenseAccountName.setSelectedIndex(0);
                if (onSuccess != null) onSuccess.run();
            } else {
                JOptionPane.showMessageDialog(null, "Cuenta no encontrada.");
            }

            accountStmt.close();

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Monto inválido.");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error SQL: " + e.getMessage());
        }
    }
}

