/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package patroness;

/**
 *
 * @author User
 */
// Observer.java
public interface Observer {
    void update();  // Método que se llamará automáticamente cuando el sujeto notifique
}
