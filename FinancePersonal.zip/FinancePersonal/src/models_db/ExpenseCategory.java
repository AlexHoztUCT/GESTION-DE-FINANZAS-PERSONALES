/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package models_db;

/**
 *
 * @author alexi
 */
public class ExpenseCategory {
    private int category_id;
    private int user_id;
    private String category_name;

    public ExpenseCategory() {}

    public ExpenseCategory(int categoryId, int userId, String categoryName) {
        this.category_id = categoryId;
        this.user_id = userId;
        this.category_name = categoryName;
    }

    public int getCategoryId() { return category_id; }
    public void setCategoryId(int categoryId) { this.category_id = categoryId; }

    public int getUserId() { return user_id; }
    public void setUserId(int userId) { this.user_id = userId; }

    public String getCategoryName() { return category_name; }
    public void setCategoryName(String categoryName) { this.category_name = categoryName; }
}
