
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


// view_principal/AccountDAOImpl.java
// view_principal/AccountDAOImpl.java
package view_principal;

import interfaces.AccountDAO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.math.BigDecimal;
import models_db.Account;

public class AccountDAOImpl implements AccountDAO {
    private Connection connection;

    public AccountDAOImpl(Connection connection) {
        this.connection = connection;
    }

    @Override
    public void addAccount(Account account) throws SQLException {
        String sql = "INSERT INTO account (user_id, account_type, balance, liabilities) VALUES (?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, account.getUserId());
            stmt.setString(2, account.getAccountType());
            stmt.setBigDecimal(3, account.getBalance());
            stmt.setBigDecimal(4, account.getLiabilities());
            stmt.executeUpdate();
        }
    }

    @Override
    public void deleteAccount(int accountId) throws SQLException {
        String sql = "DELETE FROM account WHERE account_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, accountId);
            stmt.executeUpdate();
        }
    }
}


