/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package personal_finance_managment;

import Login.Login;
import com.formdev.flatlaf.themes.FlatMacLightLaf; // Importa FlatLaf, un Look and Feel para interfaces gráficas de usuario que proporciona un estilo visual similar al de macOS.

/**
 *
 * @author alex
 */
public class PersonalFinanceManagement {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        FlatMacLightLaf.setup();
        // TODO code application logic here
        Login LoginFrame = new Login();
        LoginFrame.setVisible(true);
        LoginFrame.pack();
        LoginFrame.setLocationRelativeTo(null); 
    }
    
}
