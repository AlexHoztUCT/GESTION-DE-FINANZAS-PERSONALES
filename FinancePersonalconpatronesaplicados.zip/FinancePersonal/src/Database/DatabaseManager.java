/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Database;

/**
 *
 * @author DAVID CALFULEN
 */
import java.sql.*; // Importar clases necesarias para trabajar con JDBC y SQL

public class DatabaseManager {
    // URL de conexión a la base de datos MySQL
    private static final String URL = "jdbc:mysql://localhost:3306/gestion_finanzas";
    private static final String USER = "root"; // Nombre de usuario de la base de datos
    private static final String PASSWORD = "";  // Contraseña para el usuario (aquí está vacía)

    // Variables para la conexión y la declaración
    private static Connection connection;
    private static Statement statement;

    // Método para obtener la conexión actual
    public static Connection getConnection() {
        return connection; // Retorna la conexión
    }

    // Método para establecer la conexión a la base de datos
    public static void connect() {
        try {
            // Cargar el driver de MySQL
            Class.forName("com.mysql.cj.jdbc.Driver");
            // Establecer la conexión usando la información definida anteriormente
            connection = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println("Conectado a la base de datos"); // Confirmar conexión establecida

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace(); // Imprimir el seguimiento de la excepción en caso de error
        }
    }

    // Método para ejecutar una consulta y retornar el ResultSet
    public static ResultSet executeQuery(String query) {
        ResultSet resultSet = null; // Inicializar el ResultSet

        try {
            // Crear una declaración para ejecutar la consulta
            statement = connection.createStatement();
            // Ejecutar la consulta y almacenar el resultado
            resultSet = statement.executeQuery(query);
        } catch (SQLException e) {
            e.printStackTrace(); // Imprimir el seguimiento de la excepción en caso de error
        }

        return resultSet; // Retornar el ResultSet que contiene los resultados de la consulta
    }

}