/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prototype;

/**
 *
 * @author vale
 */
import java.util.Date;

public class ConcreteExpenseFactory implements ExpenseFactory {
    @Override
    public Expense createExpense(int userId, int accountId, Date date, String category, String remark, double amount) {
        return new ExpenseImpl(userId, accountId, date, category, remark, amount);
    }
}
