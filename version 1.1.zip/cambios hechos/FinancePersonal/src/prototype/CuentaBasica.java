/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prototype;

/**
 *
 * @author User
 */

import Database.DatabaseManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class CuentaBasica extends Cuenta {

    public CuentaBasica(String nombre, int userId) {
        super(nombre, userId);
    }

    @Override
    public void guardarEnBD() {
        try {
            DatabaseManager.connect();

            String query = "INSERT INTO account(account_type, balance, user_id, liabilities) VALUES (?, ?, ?, ?)";
            PreparedStatement pstmt = DatabaseManager.getConnection().prepareStatement(query);
            pstmt.setString(1, nombre);
            pstmt.setDouble(2, 0.0);
            pstmt.setInt(3, userId);
            pstmt.setDouble(4, 0.0);

            int filas = pstmt.executeUpdate();
            if (filas > 0) {
                JOptionPane.showMessageDialog(null, "Cuenta creada con éxito!");
            } else {
                JOptionPane.showMessageDialog(null, "No se pudo crear la cuenta.");
            }
            pstmt.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al guardar cuenta: " + ex.getMessage());
        }
    }
}
