package prototype;

import java.util.Date;

public class ExpenseImpl implements Expense {
    private int userId;
    private int accountId;
    private Date date;
    private String category;
    private String remark;
    private double amount;

    public ExpenseImpl(int userId, int accountId, Date date, String category, String remark, double amount) {
        this.userId = userId;
        this.accountId = accountId;
        this.date = date;
        this.category = category;
        this.remark = remark;
        this.amount = amount;
    }

    @Override
    public int getUserId() { return userId; }

    @Override
    public int getAccountId() { return accountId; }

    @Override
    public Date getDate() { return date; }

    @Override
    public String getCategory() { return category; }

    @Override
    public String getRemark() { return remark; }

    @Override
    public double getAmount() { return amount; }
}
