/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package patrones_estructurales;

/**
 *
 * @author maxim
 */
import javax.swing.JPanel;
import views_secundary.INICIO;

public class UIDecorator implements UIComponent {
    private final UIComponent wrappedComponent;

    public UIDecorator(UIComponent component) {
        this.wrappedComponent = component;
    }

    @Override
    public JPanel getPanel() {
        if (wrappedComponent.getPanel() instanceof INICIO inicio) {
            inicio.updateComponents();
        }
        return wrappedComponent.getPanel();
    }
}