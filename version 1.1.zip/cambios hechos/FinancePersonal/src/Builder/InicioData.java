/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Builder;

/**
 *
 * @author User
 */
import javax.swing.table.DefaultTableModel;

public class InicioData {
    public int totalBalance;
    public int totalLiabilities;
    public int totalIncome;
    public int totalExpense;
    public DefaultTableModel transactionsModel;
    public int progressValue;
    public String progressText;
}

