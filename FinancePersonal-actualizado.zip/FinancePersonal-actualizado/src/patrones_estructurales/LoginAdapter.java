/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package patrones_estructurales;

/**
 *
 * @author maxim
 */
import javax.swing.JPanel;
import Login.Login;

public class LoginAdapter implements UIComponent {
    private final Login loginFrame;

    public LoginAdapter() {
        this.loginFrame = new Login();
    }

    @Override
    public JPanel getPanel() {
        // Adaptamos el JFrame a JPanel
        JPanel container = new JPanel();
        container.add(loginFrame.getContentPane());
        return container;
    }

    public void showLogin() {
        loginFrame.setVisible(true);
    }
}