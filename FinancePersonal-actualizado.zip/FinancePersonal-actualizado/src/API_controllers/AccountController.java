/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


// Paquete donde se encuentra la clase
package API_controllers;

// Importaciones necesarias
import API_models_db.Account;
import API_services.AccountService;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.*;
import java.util.List;

/**
 * Controlador REST para gestionar cuentas (Accounts).
 * Expone endpoints CRUD bajo la ruta base "/accounts".
 * 
 * Usa JAX-RS para manejar solicitudes HTTP y JSON como formato de entrada/salida.
 */
@Path("/Account")  // Ruta base para todos los endpoints de este controlador
@Produces(MediaType.APPLICATION_JSON)  // Todas las respuestas serán en formato JSON
@Consumes(MediaType.APPLICATION_JSON)  // Acepta solo solicitudes con cuerpo JSON
public class AccountController {
    
    // Inyección de dependencia (en este caso, instanciación directa por simplicidad)
    private final AccountService accountService = new AccountService();

    /**
     * Obtiene todas las cuentas existentes.
     * 
     * @return Response con lista de cuentas (HTTP 200) o error si falla.
     */
    @GET  // Método HTTP GET
    public Response getAllAccounts() {
        List<Account> accounts = accountService.getAllAccounts();
        return Response.ok(accounts).build();  // HTTP 200 + JSON con las cuentas
    }

    /**
     * Obtiene una cuenta específica por su ID.
     * 
     * @param id ID de la cuenta (en la URL).
     * @return Response con la cuenta (HTTP 200) o NOT_FOUND (HTTP 404) si no existe.
     */
    @GET
    @Path("/{id}")  // Ruta dinámica: /accounts/{id} (ej: /accounts/123)
    public Response getAccountById(@PathParam("id") int id) {
        Account account = accountService.getAccountById(id);
        if (account != null) {
            return Response.ok(account).build();  // HTTP 200 + JSON con la cuenta
        } else {
            return Response.status(Response.Status.NOT_FOUND).build();  // HTTP 404
        }
    }

    /**
     * Crea una nueva cuenta.
     * 
     * @param account Datos de la cuenta (en el cuerpo de la solicitud como JSON).
     * @param uriInfo Información de la URI (para construir la respuesta).
     * @return Response HTTP 201 (Created) con la URI del nuevo recurso y la cuenta creada.
     */
    @POST  // Método HTTP POST
    public Response createAccount(Account account, @Context UriInfo uriInfo) {
        Account createdAccount = accountService.createAccount(account);
        // Construye la URI del nuevo recurso (ej: /accounts/123)
        UriBuilder builder = uriInfo.getAbsolutePathBuilder();
        builder.path(Integer.toString(createdAccount.getAccountId()));
        // HTTP 201 + cabecera "Location" con la URI + cuerpo con la cuenta creada
        return Response.created(builder.build()).entity(createdAccount).build();
    }

    /**
     * Actualiza una cuenta existente.
     * 
     * @param id ID de la cuenta (en la URL).
     * @param account Datos actualizados de la cuenta (en el cuerpo como JSON).
     * @return Response con la cuenta actualizada (HTTP 200) o error si falla.
     */
    @PUT
    @Path("/{id}")
    public Response updateAccount(@PathParam("id") int id, Account account) {
        account.setAccountId(id);  // Asegura que el ID coincida con la URL
        Account updatedAccount = accountService.updateAccount(account);
        return Response.ok(updatedAccount).build();  // HTTP 200 + JSON con la cuenta
    }

    /**
     * Elimina una cuenta existente.
     * 
     * @param id ID de la cuenta (en la URL).
     * @return Response sin contenido (HTTP 204) o error si falla.
     */
    
    @DELETE
    @Path("/{id}")
    public Response deleteAccount(@PathParam("id") int id) {
        accountService.deleteAccount(id);
        return Response.noContent().build();  // HTTP 204 (No Content)
    }
}
