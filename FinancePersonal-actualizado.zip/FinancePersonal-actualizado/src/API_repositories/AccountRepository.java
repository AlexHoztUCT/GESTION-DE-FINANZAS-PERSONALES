/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

// ACCESO A DATOS

package API_repositories;

import API_models_db.Account;
import Database.DatabaseManager;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AccountRepository {
    
    public List<Account> findAll() {
        List<Account> accounts = new ArrayList<>();
        String sql = "SELECT * FROM account"; // Usando el nombre correcto de tabla
        
        try (Connection conn = DatabaseManager.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                Account account = new Account(
                    rs.getInt("account_id"),
                    rs.getInt("user_id"),
                    rs.getString("account_type"),
                    rs.getBigDecimal("balance"),
                    rs.getBigDecimal("liabilities")
                );
                accounts.add(account);
            }
        } catch (SQLException e) {
            System.err.println("Error al obtener cuentas: " + e.getMessage());
            e.printStackTrace();
        }
        return accounts;
    }
    
    public Account findById(int id) {
        String sql = "SELECT * FROM account WHERE account_id = ?";
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                return new Account(
                    rs.getInt("account_id"),
                    rs.getInt("user_id"),
                    rs.getString("account_type"),
                    rs.getBigDecimal("balance"),
                    rs.getBigDecimal("liabilities")
                );
            }
        } catch (SQLException e) {
            System.err.println("Error al buscar cuenta por ID: " + e.getMessage());
        }
        return null;
    }
    
    public Account save(Account account) {
        String sql = "INSERT INTO account (user_id, account_type, balance, liabilities) VALUES (?, ?, ?, ?)";
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            stmt.setInt(1, account.getUserId());
            stmt.setString(2, account.getAccountType());
            stmt.setBigDecimal(3, account.getBalance());
            stmt.setBigDecimal(4, account.getLiabilities());
            
            int affectedRows = stmt.executeUpdate();
            if (affectedRows == 0) {
                throw new SQLException("Creating account failed, no rows affected.");
            }
            
            try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    account.setAccountId(generatedKeys.getInt(1));
                    return account;
                } else {
                    throw new SQLException("Creating account failed, no ID obtained.");
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al guardar cuenta: " + e.getMessage());
            return null;
        }
    }
    
    public Account update(Account account) {
        String sql = "UPDATE account SET user_id = ?, account_type = ?, balance = ?, liabilities = ? WHERE account_id = ?";
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, account.getUserId());
            stmt.setString(2, account.getAccountType());
            stmt.setBigDecimal(3, account.getBalance());
            stmt.setBigDecimal(4, account.getLiabilities());
            stmt.setInt(5, account.getAccountId());
            
            int affectedRows = stmt.executeUpdate();
            if (affectedRows > 0) {
                return account;
            }
        } catch (SQLException e) {
            System.err.println("Error al actualizar cuenta: " + e.getMessage());
        }
        return null;
    }
    
    public boolean delete(int id) {
        String sql = "DELETE FROM account WHERE account_id = ?";
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, id);
            int affectedRows = stmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            System.err.println("Error al eliminar cuenta: " + e.getMessage());
            return false;
        }
    }
}
