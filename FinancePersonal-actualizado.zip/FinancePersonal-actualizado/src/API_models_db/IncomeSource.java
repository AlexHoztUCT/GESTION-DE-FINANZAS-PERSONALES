/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package API_models_db;

/**
 *
 * @author alexi
 */

public class IncomeSource {
    private int source_id;
    private int user_id;
    private String source_name;

    public IncomeSource() {}

    public IncomeSource(int sourceId, int userId, String sourceName) {
        this.source_id = sourceId;
        this.user_id = userId;
        this.source_name = sourceName;
    }

    public int getSourceId() { return source_id; }
    public void setSourceId(int sourceId) { this.source_id = sourceId; }

    public int getUserId() { return user_id; }
    public void setUserId(int userId) { this.user_id = userId; }

    public String getSourceName() { return source_name; }
    public void setSourceName(String sourceName) { this.source_name = sourceName; }
}
