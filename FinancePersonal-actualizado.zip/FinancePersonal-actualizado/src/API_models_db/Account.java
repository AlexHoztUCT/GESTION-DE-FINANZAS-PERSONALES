/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package API_models_db;

import java.math.BigDecimal;

/**
 *
 * @author alexi
 */


public class Account {
    private int account_id;
    private int user_id;
    private String account_type;
    private BigDecimal balance;
    private BigDecimal liabilities;

    public Account() {}

    public Account(int accountId, int userId, String accountType, BigDecimal balance, BigDecimal liabilities) {
        this.account_id = accountId;
        this.user_id = userId;
        this.account_type = accountType;
        this.balance = balance;
        this.liabilities = liabilities;
    }

    public int getAccountId() { return account_id; }
    public void setAccountId(int accountId) { this.account_id = accountId; }

    public int getUserId() { return user_id; }
    public void setUserId(int userId) { this.user_id = userId; }

    public String getAccountType() { return account_type; }
    public void setAccountType(String accountType) { this.account_type = accountType; }

    public BigDecimal getBalance() { return balance; }
    public void setBalance(BigDecimal balance) { this.balance = balance; }

    public BigDecimal getLiabilities() { return liabilities; }
    public void setLiabilities(BigDecimal liabilities) { this.liabilities = liabilities; }
}
