/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 *
 * @author DCalf
 */
package patroness;

import Database.DatabaseManager;
import Database.UserSession;
import com.toedter.calendar.JDateChooser;
import java.sql.*;
import java.util.Date;
import javax.swing.*;

public class AddIncomeCommand implements Command {

    private final Date incomeDate;
    private final String accountName;
    private final String incomeSource;
    private final String incomeAmountText;
    private final JComboBox<String> incomeAccountName;
    private final JComboBox<String> incomeSourceComboBox;
    private final JTextField incomeAmount;
    private final JDateChooser incomeDateChooser;
    private final Runnable onSuccess;

    public AddIncomeCommand(
            JDateChooser incomeDateChooser,
            JComboBox<String> incomeAccountName,
            JComboBox<String> incomeSourceComboBox,
            JTextField incomeAmount,
            Runnable onSuccess
    ) {
        this.incomeDateChooser = incomeDateChooser;
        this.incomeAccountName = incomeAccountName;
        this.incomeSourceComboBox = incomeSourceComboBox;
        this.incomeAmount = incomeAmount;
        this.incomeDate = incomeDateChooser.getDate();
        this.accountName = (String) incomeAccountName.getSelectedItem();
        this.incomeSource = (String) incomeSourceComboBox.getSelectedItem();
        this.incomeAmountText = incomeAmount.getText();
        this.onSuccess = onSuccess;
    }

    @Override
    public void execute() {
        if (incomeDate == null) {
            JOptionPane.showMessageDialog(null, "Por favor, seleccione la fecha de ingreso.");
            return;
        }
        if (accountName.equals("--SELECCIONAR--")) {
            JOptionPane.showMessageDialog(null, "Por favor, seleccione la cuenta.");
            return;
        }
        if (incomeSource.equals("--SELECCIONAR--") || incomeSource.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Por favor, seleccione una fuente de ingresos.");
            return;
        }
        if (incomeAmountText.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Por favor, ingrese un monto de ingresos.");
            return;
        }

        try {
            int amount = (int) Double.parseDouble(incomeAmountText);
            java.sql.Date sqlDate = new java.sql.Date(incomeDate.getTime());

            DatabaseManager.connect();

            String accountQuery = "SELECT account_id, balance FROM account WHERE account_type = ? AND user_id = ?";
            PreparedStatement accountStmt = DatabaseManager.getConnection().prepareStatement(accountQuery);
            accountStmt.setString(1, accountName);
            accountStmt.setInt(2, UserSession.userId);
            ResultSet accountResult = accountStmt.executeQuery();

            if (accountResult.next()) {
                int accountId = accountResult.getInt("account_id");
                double currentBalance = accountResult.getDouble("balance");
                double newBalance = currentBalance + amount;

                String updateQuery = "UPDATE account SET balance = ? WHERE account_id = ?";
                PreparedStatement updateStmt = DatabaseManager.getConnection().prepareStatement(updateQuery);
                updateStmt.setDouble(1, newBalance);
                updateStmt.setInt(2, accountId);
                int rowsUpdated = updateStmt.executeUpdate();

                if (rowsUpdated > 0) {
                    String insertQuery = "INSERT INTO income(user_id, account_id, income_date, income_source, amount) VALUES (?, ?, ?, ?, ?)";
                    PreparedStatement pstmt = DatabaseManager.getConnection().prepareStatement(insertQuery);
                    pstmt.setInt(1, UserSession.userId);
                    pstmt.setInt(2, accountId);
                    pstmt.setDate(3, sqlDate);
                    pstmt.setString(4, incomeSource);
                    pstmt.setDouble(5, amount);

                    int rowsInserted = pstmt.executeUpdate();

                    if (rowsInserted > 0) {
                        JOptionPane.showMessageDialog(null, "Ingreso registrado con éxito.");
                        incomeDateChooser.setDate(null);
                        incomeSourceComboBox.setSelectedIndex(0);
                        incomeAmount.setText("");
                        incomeAccountName.setSelectedIndex(0);
                        if (onSuccess != null) onSuccess.run();
                    } else {
                        JOptionPane.showMessageDialog(null, "Fallo al registrar el ingreso.");
                    }
                    pstmt.close();
                } else {
                    JOptionPane.showMessageDialog(null, "No se pudo actualizar el saldo de la cuenta.");
                }
                updateStmt.close();
            } else {
                JOptionPane.showMessageDialog(null, "Cuenta no encontrada.");
            }
            accountStmt.close();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Por favor, ingrese un número válido.");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error SQL: " + ex.getMessage());
        }
    }
}
