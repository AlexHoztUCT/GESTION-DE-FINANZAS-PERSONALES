/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

// LOGICA DEL NEGOCIO


package API_services;

import API_models_db.Account;
import API_repositories.AccountRepository;
import java.util.List;

/**
 * Capa de servicio para la gestión de cuentas (Account).
 * 
 * Responsabilidades:
 * - Orquestar operaciones entre controladores y repositorios
 * - Aplicar lógica de negocio
 * - Manejar validaciones adicionales
 * 
 * Nota: Actualmente delega al repositorio sin lógica adicional (versión básica).
 */
public class AccountService {
    
    // Dependencia: Podría mejorarse con inyección (Spring, CDI, etc.)
    private final AccountRepository accountRepository = new AccountRepository();
    
    /**
     * Obtiene todas las cuentas existentes.
     * @return Lista completa de cuentas (delegado al repositorio).
     */
    public List<Account> getAllAccounts() {
        return accountRepository.findAll();
    }
    
    /**
     * Busca una cuenta por ID.
     * @param id Identificador único de la cuenta.
     * @return La cuenta encontrada o null si no existe.
     */
    public Account getAccountById(int id) {
        return accountRepository.findById(id);
    }
    
    /**
     * Crea una nueva cuenta.
     * @param account Datos de la cuenta a crear (sin ID).
     * @return Cuenta creada con ID generado.
     */
    public Account createAccount(Account account) {
        // Punto de extensión para validaciones:
        // - Saldo mínimo inicial
        // - Límites de tipo de cuenta
        // - Verificación de usuario existente
        return accountRepository.save(account);
    }
    
    /**
     * Actualiza una cuenta existente.
     * @param account Datos actualizados (debe incluir ID válido).
     * @return Cuenta actualizada o null si no existe.
     */
    public Account updateAccount(Account account) {
        // Punto para lógica adicional:
        // - Validar cambios de saldo
        // - Registrar auditoría
        return accountRepository.update(account);
    }
    
    /**
     * Elimina una cuenta por ID.
     * @param id Identificador de la cuenta a eliminar.
     */
    public void deleteAccount(int id) {
        // Posibles mejoras:
        // - Verificar saldo cero antes de eliminar
        // - Eliminación lógica en lugar de física
        accountRepository.delete(id);
    }
}
