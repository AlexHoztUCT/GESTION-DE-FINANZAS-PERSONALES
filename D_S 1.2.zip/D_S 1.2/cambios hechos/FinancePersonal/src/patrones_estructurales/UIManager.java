/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package patrones_estructurales;

/**
 *
 * @author maxim
 */
// patron facade
import javax.swing.JPanel;
public class UIManager {
    private JPanel contentPanel;

    public UIManager(JPanel contentPanel) {
        this.contentPanel = contentPanel;
    }

    public void showPanel(JPanel panel) {
        panel.setSize(1524, 779);
        panel.setLocation(0, 0);
        contentPanel.removeAll();
        contentPanel.add(panel);
        contentPanel.revalidate();
        contentPanel.repaint();
    }
}
