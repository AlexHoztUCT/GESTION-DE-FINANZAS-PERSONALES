/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package models_db;

/**
 *
 * @author alexi
 */
public class TargetAmount {
    private int target_id;
    private int user_id;
    private double amount;

    public TargetAmount() {}

    public TargetAmount(int targetId, int userId, double amount) {
        this.target_id = targetId;
        this.user_id = userId;
        this.amount = amount;
    }

    public int getTargetId() { return target_id; }
    public void setTargetId(int targetId) { this.target_id = targetId; }

    public int getUserId() { return user_id; }
    public void setUserId(int userId) { this.user_id= userId; }

    public double getAmount() { return amount; }
    public void setAmount(double amount) { this.amount = amount; }
}

