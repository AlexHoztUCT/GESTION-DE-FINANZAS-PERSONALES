/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package patrones_estructurales;

/**
 *
 * @author maxim
 */
// patron facade

import com.formdev.flatlaf.themes.FlatMacLightLaf;
import javax.swing.*;

public class UIManager {

    public static void setLookAndFeel(FlatMacLightLaf flatMacLightLaf) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    private final JPanel contentPanel;
    private UIComponent currentComponent;

    public UIManager(JPanel contentPanel) {
        this.contentPanel = contentPanel;
    }

    public void showComponent(UIComponent component) {
        JPanel panel = component.getPanel();
        panel.setSize(1524, 779);
        panel.setLocation(0, 0);
        
        contentPanel.removeAll();
        contentPanel.add(panel);
        contentPanel.revalidate();
        contentPanel.repaint();
        
        currentComponent = component;
    }
}