/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package patrones_estructurales;

/**
 *
 * @author maxim
 */
import javax.swing.JPanel;

public class PanelAdapter implements UIComponent {
    private final JPanel panel;

    public PanelAdapter(JPanel panel) {
        this.panel = panel;
    }

    @Override
    public JPanel getPanel() {
        return panel;
    }
}