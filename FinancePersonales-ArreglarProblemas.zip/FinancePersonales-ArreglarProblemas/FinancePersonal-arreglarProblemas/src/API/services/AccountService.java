/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

// LOGICA DEL NEGOCIO

package API.services;

import API.models_db.Account;
import API.repositories.AccountRepository;
import java.util.List;

public class AccountService {
    
    private final AccountRepository accountRepository = new AccountRepository();
    
    public List<Account> getAllAccounts() {
        return accountRepository.findAll();
    }
    
    public Account getAccountById(int id) {
        return accountRepository.findById(id);
    }
    
    public Account createAccount(Account account) {
        // Validaciones adicionales aquí
        return accountRepository.save(account);
    }
    
    public Account updateAccount(Account account) {
        // Validaciones adicionales aquí
        return accountRepository.update(account);
    }
    
    public void deleteAccount(int id) {
        accountRepository.delete(id);
    }
}
