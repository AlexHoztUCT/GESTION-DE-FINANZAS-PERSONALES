/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package API.models_db;
import java.util.Date;


/**
 *
 * @author alexi
 */

public class Income {
    private int income_id;
    private int user_id;
    private int account_id;
    private Date income_date;
    private String income_source;
    private double amount;

    public Income() {}

    public Income(int incomeId, int userId, int accountId, Date incomeDate, String incomeSource, double amount) {
        this.income_id = incomeId;
        this.user_id = userId;
        this.account_id = accountId;
        this.income_date = incomeDate;
        this.income_source = incomeSource;
        this.amount = amount;
    }

    public int getIncomeId() { return income_id; }
    public void setIncomeId(int incomeId) { this.income_id = incomeId; }

    public int getUserId() { return user_id; }
    public void setUserId(int userId) { this.user_id = userId; }

    public int getAccountId() { return account_id; }
    public void setAccountId(int accountId) { this.account_id = accountId; }

    public Date getIncomeDate() { return income_date; }
    public void setIncomeDate(Date incomeDate) { this.income_date = incomeDate; }

    public String getIncomeSource() { return income_source; }
    public void setIncomeSource(String incomeSource) { this.income_source = incomeSource; }

    public double getAmount() { return amount; }
    public void setAmount(double amount) { this.amount = amount; }
}



