/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


package config;

import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.servlet.ServletContextHandler;
import org.eclipse.jetty.servlet.ServletHolder;
import org.glassfish.jersey.server.ResourceConfig;
import org.glassfish.jersey.servlet.ServletContainer;

public class Main {
    public static void main(String[] args) {
        try {
            Server server = new Server(8080);
            
            ServletContextHandler context = new ServletContextHandler();
            context.setContextPath("/");
            
            ResourceConfig config = new ResourceConfig();
            config.packages("API.controllers"); // Paquete de tus controladores
            
            ServletHolder jerseyServlet = new ServletHolder(
                new ServletContainer(config)
            );
            context.addServlet(jerseyServlet, "/*");
            
            server.setHandler(context);
            server.start();
            System.out.println("✅ Servidor activo en http://localhost:8080");
            server.join();
        } catch (Exception e) {
            System.err.println("❌ Error al iniciar el servidor:");
            e.printStackTrace();
        }
    }
}